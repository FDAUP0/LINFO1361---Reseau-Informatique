# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>


int create_and_send_message(const struct sockaddr *dest_addr, socklen_t addrlen) {
    // TODO: Create a IPv6 socket supporting datagrams
    int sock = socket(AF_INET6, SOCK_DGRAM, 0);
    if (sock == -1) {
        printf("aie");
        return -1;
    }
    // TODO: Connect it to the destination
    int con = connect(sock, dest_addr, addrlen);
        if (con == -1) {
        printf("aie");
        return -1;
    }
    // TODO: Send the required message (cfr. statement) through the socket
    int msg[5];
    for(int i = 0; i < 5; i ++){
        msg[i] = htonl((2*i) +1);
    }
    ssize_t truc = send(sock, msg , 5* sizeof(int), 0); 
    if (truc == -1) {
        printf("aie");
        return -1;
    }
    
    
    return 0;
}

int recv_and_handle_message(const struct sockaddr *src_addr, socklen_t addrlen) {
    // TODO: Create a IPv6 socket supporting datagrams
    int sock = socket(AF_INET6, SOCK_DGRAM, 0);
    if (sock == -1) {
        printf("aie");
        return -1;
    }
    // TODO: Bind it to the source
    int bd =  bind(sock, src_addr, addrlen);
    if (bd == -1) {
        printf("aie");
        return -1;
    }
    // TODO: Receive a message through the socket
    int buf[1024];
    struct sockaddr_storage sas;
    socklen_t lsas = sizeof(struct sockaddr_storage);
    
    ssize_t n_received  = recvfrom(sock, buf, 1024, 0, (struct sockaddr*)  &sas, &lsas);
    if (n_received == -1){
        return -1;
    }
    
    // TODO: Perform the computation
    int a = 0;
    for(int i = 0; i < n_received/4; i ++){
        a += ntohl(buf[i]);
    }
    // TODO: Send back the result
    int tosend = htonl(a);
    ssize_t truc = sendto( sock, &tosend , 4, 0,(struct sockaddr*) &sas, lsas);
    if (truc == -1) {
        printf("aie");
        return -1;
    }
    return 0;

}

int recv_and_handle_message(const struct sockaddr *src_addr, socklen_t addrlen) {
    // TODO: Create a IPv6 socket supporting datagrams
    int sock = socket(AF_INET6, SOCK_DGRAM, 0);
    if (sock == -1) return -1;
    // TODO: Bind it to the source
    if (bind(sock, src_addr, addrlen) == -1) {
        return -1;
    }
    // TODO: Receive a message through the socket
    int buf[1024];
    struct sockaddr_storage sas;
    socklen_t lsas = sizeof(struct sockaddr_storage);
    
    ssize_t n_received  = recvfrom(sock, buf, 1024, 0, (struct sockaddr*)  &sas, &lsas);
    if (n_received == -1){
        return -1;
    }
    
    // TODO: Perform the computation
    int sum = 0;
    for(int i = 0; i < n_received/4; i ++){
        sum += ntohl(buf[i]);
    }
    char format[1024];
    int size = sprintf(format,"%d",sum);

    // TODO: Send back the result

   
    ssize_t truc = sendto( sock, format , size, 0,(struct sockaddr*) &sas, lsas);
    if (truc == -1) {
        printf("aie");
        return -1;
    }
    return 0;
}

/**
 * `ints` is a pointer to a buffer of `no_int` integers.series of integers
 * `operation` is char representing the operation to request, '+' being the sum, and '*' being the multiplication.
 * `output_format` is char representing the output format to request, 'd' being network-ordered integers and 's' being ASCII strings.
  
  
   After sending the request, wait for the receipt of the response and return the result of the operation.
 
 */
int create_and_send_message(const struct sockaddr *dest_addr, socklen_t addrlen, int *ints, size_t no_int, char operation, char output_format, int *result) {
    // TODO: Create a socket supporting datagrams
    int sock = socket(AF_INET6, SOCK_DGRAM, 0);
    if (sock == -1) return -1;
    // TODO: Connect the socket
    int con = connect(sock, dest_addr, addrlen);
    if (con == -1) {
        printf("aie");
        return -1;
    }
    // TODO: Create the request message
    // sends ints in the correct format to the given server address.
    // Set the correct operation in the request based on the function parameters.
    char *msg = (char *) malloc(no_int*4 +1);
    // set a header byte
    char header_byte = 0;
    if (output_format == 's') {
        // header_byte = 00000001
        header_byte += 1;
    }if (operation == '*'){
        // header_byte += 00000010
        header_byte += 2;
    }
    msg[0] = header_byte;
    // copy the ints to the message
    for (int i = 0; i < (int) no_int; i++) {
        int *ptr = (int *) (msg + 1 + i*4);
        *ptr = htonl(ints[i]);
    }
    // TODO: send the request message
    ssize_t truc = send(sock, msg , no_int*4 +1, 0);
    if (truc == -1) return -1;
    

    // TODO: Receive the result
    char *buf = (char *) malloc(257*sizeof(char));
    struct sockaddr_storage sas;
    socklen_t lsas = sizeof(struct sockaddr_storage);

    ssize_t n_received  = recvfrom(sock, buf, 257, 0, (struct sockaddr*)  &sas, &lsas);
    if (n_received == -1) return -1;

    // if the first bit of the buffer is 1, return -1
    if ((buf[0] &= 128 )== 1) {
        return -1;
    }
    // TODO: return the result using the result argument
    if (output_format == 'd') {
        // return the result as a network-ordered integer

        *result = ntohl(buf[1]);
    } else {
        // return the result as string
        *result = atoi(buf+1);
    }

    return 0;


}

int recv_and_handle_message(const struct sockaddr *src_addr, socklen_t addrlen) {
    // TODO: Create a IPv6 socket supporting datagrams
    int sock = socket(AF_INET6, SOCK_DGRAM, 0);
    if (sock == -1) return -1;
    // TODO: Bind it to the source
    int err = (bind(sock, src_addr, addrlen));
    if (err == -1) return -1;
    // TODO: Receive a message through the socket
    int buf[1024];
    struct sockaddr_storage sas;
    socklen_t lsas = sizeof(struct sockaddr_storage);
    
    ssize_t n_received  = recvfrom(sock, buf, 1024, 0, (struct sockaddr*)  &sas, &lsas);
    if (n_received == -1)return -1;
    // TODO: Perform the computation
    int a = 0;
    for(int i = 0; i < n_received/4; i ++){
        a += ntohl(buf[i]);
    }
    // TODO: Send back the result
    int tosend = htonl(a);
    ssize_t truc = sendto( sock, &tosend , 4, 0,(struct sockaddr*) &sas, lsas);
    if (truc == -1) return -1;
    return 0;
}
